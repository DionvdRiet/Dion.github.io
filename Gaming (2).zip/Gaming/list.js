function state1(){
	document.getElementById("downlight1").style.backgroundColor = "#F95385";
	document.getElementById("downlight1").style.transition = "all 0.2s";
}

function state2(){
	document.getElementById("downlight2").style.backgroundColor = "#F95385";
	document.getElementById("downlight2").style.transition = "all 0.2s";
}

function state3(){
	document.getElementById("downlight3").style.backgroundColor = "#F95385";
	document.getElementById("downlight3").style.transition = "all 0.2s";
}

function offstate1(){
	document.getElementById("downlight1").style.backgroundColor = "#1a2135";
}

function offstate2(){
	document.getElementById("downlight2").style.backgroundColor = "#1a2135";
}

function offstate3(){
	document.getElementById("downlight3").style.backgroundColor = "#1a2135";
}

function heart(){
	document.getElementById("heart").style.backgroundImage = "url(Afbeeldingen/Icons/heart-dicht.svg)";
}
