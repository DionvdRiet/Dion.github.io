function nieuws1on(){
	document.getElementById("nieuws-foto1").style.backgroundImage = "linear-gradient(to right, rgba(249,83,133,0.6), rgba(255,237,138,0.6)), url(Afbeeldingen/Nieuws/BF5-zw.jpg)";
}

function nieuws1off(){
	document.getElementById("nieuws-foto1").style.backgroundImage = "url(Afbeeldingen/Nieuws/BF5.jpg)";
}

function nieuws2on(){
	document.getElementById("nieuws-foto2").style.backgroundImage = "linear-gradient(to right, rgba(249,83,133,0.6), rgba(255,237,138,0.6)), url(Afbeeldingen/Nieuws/RDR2-zw.jpg)";
}

function nieuws2off(){
	document.getElementById("nieuws-foto2").style.backgroundImage = "url(Afbeeldingen/Nieuws/RDR2.jpg)";
}

function nieuws3on(){
	document.getElementById("nieuws-foto3").style.backgroundImage = "linear-gradient(to right, rgba(249,83,133,0.6), rgba(255,237,138,0.6)), url(Afbeeldingen/Nieuws/Death-Stranding-zw.jpg)";
}

function nieuws3off(){
	document.getElementById("nieuws-foto3").style.backgroundImage = "url(Afbeeldingen/Nieuws/Death-Stranding.jpg)";
}