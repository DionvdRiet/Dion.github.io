/*var api = "http://api.openweathermap.org/data/2.5/weather?q=Paris&appid=f7f1680fa8f3203a7bd7724195d79100";
var apiKey = "f7f1680fa8f3203a7bd7724195d79100";

var */

var weather;
function setup(){
	createCanvas(200, 200);
	loadJSON('http://api.openweathermap.org/data/2.5/weather?q=Paris&appid=f7f1680fa8f3203a7bd7724195d79100', gotData, 'jsonp');
}

function gotData(data){
	weather = data;
}

function draw(){
	background(0);
	if (weather){
		ellipse(50, 100, weather.main.temp, weather.main.temp);
		ellipse(50, 100, weather.main.humidity, weather.main.temp);
	}
}

//Om te testen dat het goed gelinkt is:
//document.body.style.backgroundColor = 'red';